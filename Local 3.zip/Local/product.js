// 1. AAPKA DATA BOX (Yahan humne aapka Gojo Chibi Model add kar diya hai)
const allProductsData = {
  
  // Aapka manga hua unique product name/ID
  "gojo-1": {
    title: "Gojo Chibi Model - Jujutsu Kaisen Special",
    price: "₹1,000",
    category: "Anime > Action Figures",
    // Premium dynamic dummy URLs (Aap chahein toh baad me inhe apni local images se badal sakte hain)
    images: [
      "images/gojo.jpeg", // Front View
      "images/gojo.jpeg", // Side View
      "images/gojo.jpeg"  // Close-up View
    ],
    // Aapke product ke liye custom description
    description: "Bring home the strongest Jujutsu Sorcerer in his cutest avatar! This premium Gojo Satoru Chibi Model features impeccable details, capturing his iconic blindfold, silver hair, and cool jujutsu posture. Made with high-quality, durable PVC material, it is the perfect collectible ornament for your study desk, gaming setup, or anime shelf."
  }

};

// 2. URL PARAMETERS SE DATA READ KARNA
const urlParameters = new URLSearchParams(window.location.search);
const clickedProductId = urlParameters.get('id');
const productInfo = allProductsData[clickedProductId];

// 3. HTML ELEMENT HOOKS
const mainImgElement = document.getElementById('mainProductImg');
const thumbContainer = document.getElementById('thumbnailContainer');
const titleElement = document.getElementById('mainProductTitle');
const priceElement = document.getElementById('mainProductPrice');
const descElement = document.querySelector('.product-description'); // Hamare pichle description tag ke liye
const breadcrumbElement = document.querySelector('.breadcrumb');

// 4. DATA INJECTION LOGIC
if (productInfo) {
  titleElement.innerText = productInfo.title;
  priceElement.innerText = productInfo.price;
  
  // Custom description text content inject karna
  if (descElement) {
    descElement.innerText = productInfo.description;
  }
  
  if (breadcrumbElement) {
    breadcrumbElement.innerText = `Home > Shop > ${productInfo.category}`;
  }
  
  mainImgElement.src = productInfo.images[0];
  thumbContainer.innerHTML = "";

  productInfo.images.forEach((imageSrc, index) => {
    const thumbImg = document.createElement('img');
    thumbImg.src = imageSrc;
    thumbImg.classList.add('thumb-pic');
    thumbImg.alt = `Gojo View ${index + 1}`;

    thumbImg.addEventListener('click', () => {
      mainImgElement.src = imageSrc;
    });

    thumbContainer.appendChild(thumbImg);
  });
} else {
  if (titleElement) titleElement.innerText = "Product Not Found!";
}

