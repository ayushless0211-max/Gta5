// app.js (Aapki alag JS file)

// 1. Sabse pehle Firebase CDN se import karein
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// 2. Aapka Firebase config object
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// 3. Firebase ko initialize karein
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

  const email = document.getElementById('email').value;
  const password = document.getElementById('password');

const submit = document.getElementById('submit');
submit.addEventListener('click', () => {
    alert('Hello! This is an alert message.');
});

const button = document.getElementById('myButton');
button.addEventListener('click', () => {
    alert('Hello! This is an alert message.');
});


//firebase

  
  
  