// Grabbing HTML DOM Elements
const openBtn = document.getElementById('menuOpenBtn');
const closeBtn = document.getElementById('menuCloseBtn');
const sideMenu = document.getElementById('sideMenu');
const backdrop = document.getElementById('menuBackdrop');

// Function to trigger opening animations
function openNavMenu() {
  sideMenu.classList.add('is-active');
  backdrop.classList.add('is-active');
  document.body.style.overflow = 'hidden'; // Disables background scrolling while menu is open
}

// Function to trigger closing animations
function closeNavMenu() {
  sideMenu.classList.remove('is-active');
  backdrop.classList.remove('is-active');
  document.body.style.overflow = ''; // Restores regular scrolling mechanics
}

// Global Event Listeners
openBtn.addEventListener('click', openNavMenu);
closeBtn.addEventListener('click', closeNavMenu);
backdrop.addEventListener('click', closeNavMenu);

// Saare Add to Cart buttons ko select karna
const cartButtons = document.querySelectorAll('.addToCart');

cartButtons.forEach(button => {
  button.addEventListener('click', (event) => {
    // Yeh line product page khulne se rokegi jab sirf button click ho
    event.preventDefault(); 
    
    alert("Item added to cart successfully!");
  });
});

firebase.auth().onAuthStateChanged((user) => {
  const loginBtn = document.querySelector('.login-btn');
  if (user) {
    // User login hai -> button text badal do aur use logout button bana do
    loginBtn.innerText = "Log Out";
    loginBtn.href = "#";
    loginBtn.addEventListener('click', () => {
      firebase.auth().signOut().then(() => {
        alert("Logged out successfully!");
        window.location.reload();
      });
    });
  } else {
    // User login nahi hai
    loginBtn.innerText = "Log In";
    loginBtn.href = "login.html";
  }
});
